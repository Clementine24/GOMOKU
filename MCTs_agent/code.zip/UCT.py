from math import sqrt, log
import random
from config import *
from Board import Board
from Evaluator import Evaluator
import copy
from time import time


class UCTNode:
    def __init__(self, board: Board, parent=None, action=None):
        self.board = board
        self.rule = self.board.turn
        self.parent = parent
        self.actions_results_MC = {}
        self.actions_results_RAVE = {}
        self.children = {}
        self.num_of_playouts = 0
        self.is_fully_expanded = False
        self.action = action
        self.untried_actions = self.get_actions()
        self.is_terminal = self.board.state

    def __repr__(self):
        res = "A node with: \n"
        res += f"{self.rule=},\n{self.num_of_playouts=},\n{self.is_fully_expanded=}"
        return res

    def is_root(self):
        return self.parent is None

    def get_actions(self):
        if not self.board.hall:
            return {(self.board.height // 2, self.board.width // 2)}
        return self.board.hall

    def create_child(self, action):
        board_copy = copy.deepcopy(self.board)
        board_copy.move(action)
        board_copy.check_if_terminated()
        child = UCTNode(board_copy, parent=self, action=action)
        self.children[action] = child
        self.actions_results_MC[action] = {'count': 0, 'utility': 0}
        node = self
        while node:
            node.actions_results_RAVE.setdefault(action, {'count': 0, 'utility': 0})
            node = node.parent
        return child

    def get_priority(self, action, c=C):
        """
        The priority of an action a in state s under UCB1 selection policy.
        :param action: The action whose priority need to be computed
        :param c: The constant that balances exploitation and exploration
        :return priority: The action's priority
        """

        # Q-MC
        count_MC, utility_MC = self.actions_results_MC[action].values()
        Q_MC = utility_MC / 1 if count_MC != 0 else float("inf")

        # exploration term
        exploration = c * sqrt(log(self.num_of_playouts) / count_MC)
        # return Q_MC + exploration

        # Q-RAVE
        count_RAVE, utility_RAVE = self.actions_results_RAVE[action].values()
        Q_RAVE = utility_RAVE / 1 if count_RAVE != 0 else float("inf")

        # balancing parameter beta
        # k = 200
        # beta = sqrt(k / (3 * self.num_of_playouts + k))
        beta = max(0.0, (300 - self.num_of_playouts) / 300)
        return (1 - beta) * Q_MC + beta * Q_RAVE + exploration

    def get_best_child(self):
        """
        Get best child of the node with respect to priority.
        :return:
        """
        best_action = max(self.actions_results_MC.keys(), key=lambda action: self.get_priority(action))
        return self.children[best_action]

    def get_forced_action(self, evaluator: Evaluator):
        for action in self.get_actions():
            if evaluator.check_single_pattern(self.board, action):
                return action
        return None


class UCTSearchAgent:
    def __init__(self, board: Board, evaluator: Evaluator):
        self.evaluator = evaluator
        self.root = UCTNode(board)
        self.best_action = None

    def select(self, node: UCTNode):
        while not node.is_terminal and node.is_fully_expanded:
            node = node.get_best_child()
        return node  # Now it is a leaf

    def expand(self, node: UCTNode):
        if node.is_terminal:
            return node
        action = random.choice(list(node.untried_actions))
        node.untried_actions.discard(action)
        if len(node.untried_actions) == 0:
            node.is_fully_expanded = True
        return node.create_child(action)

        # actions = node.get_actions()
        # for action in actions:
        #     if action not in node.actions_results_MC:
        #         child = node.create_child(action)
        #         # node.actions_children[action] = child
        #         if len(actions) == len(node.actions_results_MC):
        #             node.is_fully_expanded = True
        #         return child

    def simulate(self, node: UCTNode):
        board_copy = copy.deepcopy(node.board)
        while not node.board.check_if_terminated():
            action = random.choice(list(node.board.hall))
            node.board.move(action)
        if node.rule == BLACK:
            result = BLACK if node.board.state == "BLACK" else WHITE
        else:
            result = WHITE if node.board.state == "WHITE" else BLACK
        node.board = board_copy
        return result

    def back_propagation(self, result, node: UCTNode):
        RAVE_actions = []
        while not node.is_root():
            node.num_of_playouts += 1
            parent = node.parent
            # MC value updating
            parent.actions_results_MC[node.action]['count'] += 1
            parent.actions_results_MC[node.action]['utility'] += 1 if parent.rule == result else 0

            # RAVE value updating
            RAVE_actions.append((node.action, parent.rule))
            for action, rule in RAVE_actions:
                if parent.rule == rule:
                    parent.actions_results_RAVE[action]['count'] += 1
                    parent.actions_results_RAVE[action]['utility'] += 1 if parent.rule == result else 0
            
            # back to its parent
            node = parent
        node.num_of_playouts += 1  # root

    def search(self):
        time_start = time()
        reflex_action = self.get_reflex_action()
        if reflex_action:
            self.best_action = reflex_action
            return
        simulations = 0
        while time() - time_start < TIME_LIMIT and simulations < MAX_SIMULATIONS:
            leaf = self.select(self.root)
            child = self.expand(leaf)
            result = self.simulate(child)
            self.back_propagation(result, child)
            simulations += 1
        # self.best_action = max(self.root.actions_results_MC.items(), key=lambda x: x[1]['count'])[0]
        self.best_action = self.root.get_best_child().action

    def get_reflex_action(self):
        player = self.root.rule
        opponent = get_opponent(player)
        emergence_level = 0
        reflex_action = None
        for action in self.root.get_actions():
            self.evaluator.restart()
            action_score = self.evaluator.get_position_score(self.root.board, action)
            if action_score[player] >= Evaluator.score_table['five']:  # 该步我方得分超过五，是我方胜利点，立即采用
                return action
            elif action_score[opponent] >= Evaluator.score_table['five']:  # 该步对方得分超过五，是对方胜利点，应优先抢占
                emergence_level = 11
                reflex_action = action
            elif action_score[player] >= Evaluator.score_table['l4']:  # 该步我方得分超过活四，是我方活四点，应优先采用
                if emergence_level > 10:
                    continue
                emergence_level = 10
                reflex_action = action
            elif action_score[opponent] >= Evaluator.score_table['l4']:  # 该步对方得分超过活四，是对方活四点，应优先考虑
                if emergence_level > 9:
                    continue
                emergence_level = 9
                reflex_action = action
            elif action_score[player] >= 2 * Evaluator.score_table['s4']:  # 该步我方得分超过双眠四，是我方双眠四点，应优先考虑
                if emergence_level > 8:
                    continue
                emergence_level = 8
                reflex_action = action

            elif action_score[opponent] >= 2 * Evaluator.score_table['s4']:  #
                if emergence_level > 7:
                    continue
                emergence_level = 7
                reflex_action = action

            elif action_score[player] >= Evaluator.score_table['s4'] + Evaluator.score_table['l3']:
                if emergence_level > 6:
                    continue
                emergence_level = 6
                reflex_action = action

            elif action_score[opponent] >= Evaluator.score_table['s4'] + Evaluator.score_table['l3']:
                if emergence_level > 5:
                    continue
                emergence_level = 5
                reflex_action = action

            elif action_score[player] >= 2 * Evaluator.score_table['l3']:
                if emergence_level > 4:
                    continue
                emergence_level = 4
                reflex_action = action

            elif action_score[opponent] >= 2 * Evaluator.score_table['l3']:
                if emergence_level > 3:
                    continue
                emergence_level = 3
                reflex_action = action
            elif action_score[player] >= Evaluator.score_table['s4']:  # 该步我方得分超过冲四，是我方冲四点，值得采用
                if emergence_level > 2:
                    continue
                emergence_level = 2
                reflex_action = action
            elif action_score[player] >= Evaluator.score_table['l3']:  # 该步我方得分超过活三，是我方活三点，值得考虑
                if emergence_level > 1:
                    continue
                emergence_level = 1
                reflex_action = action
        return reflex_action

    def solve(self):
        self.search()
        return self.best_action


def main():
    board = Board(BOARD_WIDTH, BOARD_HEIGHT)
    evaluator = Evaluator()
    random.seed(10)
    # board.move((8, 0))
    # board.move((7, 0))
    # board.move((10, 0))
    # board.move((13, 0))
    # board.move((11, 0))
    # board.move((9, 1))
    # board.move((12, 0))
    # board.move((9, 2))
    # print(board)
    # evaluator = Evaluator()
    # agent = UCTSearchAgent(board, evaluator)
    # action = agent.solve()
    # board.move(action)
    # print(board)
    while True:
        time1 = time()
        evaluator = Evaluator()
        action = UCTSearchAgent(copy.deepcopy(board), evaluator).solve()
        board.move(action)
        print(board)
        board.check_if_terminated()
        if board.state:
            break
        print(time() - time1)

        evaluator = Evaluator()
        action = UCTSearchAgent(copy.deepcopy(board), evaluator).solve()
        board.move(action)
        print(board)
        board.check_if_terminated()
        if board.state:
            break
    print(board.state)


if __name__ == "__main__":
    main()
