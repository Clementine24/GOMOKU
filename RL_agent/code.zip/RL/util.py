# 时间信息
TIME_MATCH = 900
TIME_TURN = 150

# 棋盘和搜索参数
BOARD_SIZE = 20
MIN_DEPTH = 2
MAX_DEPTH = 8
MAX_ACTION_NUM = 20
RADIUS = 1
MAX_SIMULATIONS = 1
GAMMA = 0.90
ALPHA = 0.01
EPSILON = 0.25
WIN_REWARD = 10

# 方向
DIRECTIONS = ((0, 1), (1, 0), (1, 1), (1, -1))

# 棋子（同时表示玩家）
PIECE_BLACK = 0
PIECE_WHITE = 1
PIECE_EMPTY = 2
PIECE_OUTSIDE = 3

# key偏移量
KEY_OFFSET = {-4: 0, -3: 2, -2: 4, -1: 6, 1: 8, 2: 10, 3: 12, 4: 14}

# 打印出的棋子样式
VISUAL_PIECE_EMPTY = '.'
VISUAL_PIECE_BLACK = 'x'
VISUAL_PIECE_WHITE = 'o'
VISUAL_PIECE_BLACK_CUR = 'X'
VISUAL_PIECE_WHITE_CUR = 'O'

# 棋形的表示
PATTERN_1 = 0
PATTERN_S2 = 1
PATTERN_L2 = 2
PATTERN_S3 = 3
PATTERN_L3 = 4
PATTERN_S4 = 5
PATTERN_L4 = 6
PATTERN_5 = 7

# 棋型得分
WIN_SCORE = 10000  # 胜利局面评分（一定是这个分）
LOSE_SCORE = -WIN_SCORE
PATTERN_SCORES = [0, 2, 12, 18, 96, 144, 800, 1200]  # 未分胜负时的单点棋型评分

# 哈希表标志
HASH_EXACT = 0
HASH_ALPHA = 1
HASH_BETA = 2


def distance(pos1, pos2):
	dx = pos1[0] - pos2[0]
	dy = pos1[1] - pos2[1]
	
	if dx == 0:
		return dy if dy > 0 else -dy
	if dy == 0:
		return dx if dx > 0 else -dx
	if dx == dy or dx == -dy:
		return dx if dx > 0 else -dx
	return -1


# def insertion_sort(actions):
# 	for i in range(len(actions)):
# 		key = actions[i]
# 		j = i
# 		while j > 0 and actions[j - 1].value < key.value:
# 			actions[j] = actions[j - 1]
# 			j -= 1
# 		actions[j] = key


class Cell:
	"""棋盘单个位置的数据结构"""
	
	def __init__(self, piece=PIECE_EMPTY):
		self.piece = piece
		self.num_of_neighbors = 0
		self.patterns = [
			[PATTERN_1 for _ in range(4)]
			for _ in range(2)
		]
		self.key = [0 for _ in range(4)]


class Action:
	def __init__(self, position, value):
		self.position = position
		self.value = value

	


