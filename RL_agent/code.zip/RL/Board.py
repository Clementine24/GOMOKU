from random import getrandbits, seed
from util import *
from Tables import KP_TABLE
from time import time


# class Board:
# 	def __init__(self, size=BOARD_SIZE):
# 		self.size = size
# 		self.cells = [[PIECE_EMPTY for _ in range(size)] for _ in range(size)]
# 		self.num_of_neighbors = [[0 for _ in range(size)] for _ in range(size)]
# 		self.turn = PIECE_BLACK
# 		self.last_turn = PIECE_WHITE
# 		self.pre_actions = []
# 		self.step = 0
# 		self.last_action = None
# 		self.hall = set()
# 		self.state = None
# 		self.zobrist = [
# 			[[getrandbits(64) for _ in range(size)] for _ in range(size)]
# 			for _ in range(2)
# 		]
# 		self.zobrist_key = getrandbits(64)
#
# 	def __str__(self):
# 		"""
# 		转化为字符串
# 		:param:
# 		:return:
# 		"""
# 		res = f"Here is a board sized {self.size}\n"
# 		res += "   "
#
# 		for x in range(self.size):
# 			res += f"{x:2}|"
# 		res += "\n"
#
# 		for x in range(self.size):
# 			res += f"{x:2}: "
# 			for y in range(self.size):
# 				cur_pos = (x, y)
# 				owner = self.whose_chess(cur_pos)
# 				if owner is None:
# 					piece = VISUAL_PIECE_EMPTY
# 				else:
# 					if self.last_action is not None and self.last_action == cur_pos:
# 						piece = VISUAL_PIECE_BLACK_CUR if owner == PIECE_BLACK else VISUAL_PIECE_WHITE_CUR
# 					else:
# 						piece = VISUAL_PIECE_BLACK if owner == PIECE_BLACK else VISUAL_PIECE_WHITE
# 				res += piece + "| "
# 			res += "\n"
# 		return res
#
# 	def is_on_board(self, position):
# 		return 0 <= position[0] < self.size and 0 <= position[1] < self.size
#
# 	def is_empty(self, position):
# 		return self.cells[position[0]][position[1]] == PIECE_EMPTY
#
# 	def whose_chess(self, position):
# 		assert self.is_on_board(position)
# 		return None\
# 			if not self.is_on_board(position) or self.is_empty(position)\
# 			else self.cells[position[0]][position[1]]
#
# 	def get_neighbors(self, position):
# 		"""Returns the neighbors"""
# 		x, y = position
# 		# candidates = [
# 		# 	(x - 2, y - 2), (x - 2, y), (x - 2, y + 2),
# 		# 	(x - 1, y - 1), (x - 1, y), (x - 1, y + 1),
# 		# 	(x, y - 2), (x, y - 1), (x, y + 1), (x, y + 2),
# 		# 	(x + 1, y - 1), (x + 1, y), (x + 1, y + 1),
# 		# 	(x + 2, y - 2), (x + 2, y), (x + 2, y + 2)
# 		# ]
# 		candidates = [
# 			(x - 1, y - 1), (x - 1, y), (x - 1, y + 1),
# 			(x, y - 1), (x, y + 1),
# 			(x + 1, y - 1), (x + 1, y), (x + 1, y + 1)
# 		]
# 		return [candidate for candidate in candidates if self.is_on_board(candidate)]
#
# 	def make_move(self, position):
# 		assert position is not None
# 		assert self.is_empty(position)
# 		x, y = position
# 		self.zobrist_key ^= self.zobrist[self.turn][x][y]
# 		self.pre_actions.append(position)
# 		self.step += 1
# 		self.last_action = position
# 		self.cells[x][y] = self.turn
# 		self.turn, self.last_turn = self.last_turn, self.turn
# 		self.update_hall()
#
# 	def withdraw(self):
# 		assert self.whose_chess(self.last_action) == self.last_turn
# 		last_x, last_y = self.last_action
# 		self.zobrist_key ^= self.zobrist[self.last_turn][last_x][last_y]
# 		self.cells[last_x][last_y] = PIECE_EMPTY
# 		self.turn, self.last_turn = self.last_turn, self.turn
# 		self.revert_hall()
# 		self.step -= 1
# 		self.last_action = None if self.step == 0 else self.pre_actions[-1]
#
# 	def update_hall(self):
# 		for neighbor_pos in self.get_neighbors(self.last_action):
# 			n_x, n_y = neighbor_pos
# 			self.num_of_neighbors[n_x][n_y] += 1
# 			if self.cells[n_x][n_y] == PIECE_EMPTY:
# 				self.hall.add(neighbor_pos)
# 		self.hall.discard(self.last_action)
#
# 	def revert_hall(self):
# 		for neighbor_pos in self.get_neighbors(self.last_action):
# 			n_x, n_y = neighbor_pos
# 			self.num_of_neighbors[n_x][n_y] -= 1
# 			if self.num_of_neighbors[n_x][n_y] == 0 and self.cells[n_x][n_y] == PIECE_EMPTY:
# 				self.hall.discard(neighbor_pos)
# 		if self.step != 1:
# 			self.hall.add(self.last_action)
#
# 	def check_if_terminated(self):
# 		if not self.last_action:  # 如果未落子（空棋盘），不可能是终止状态
# 			self.state = None
# 			return False
# 		if self.step == self.size * self.size:
# 			self.state = "DRAW"
# 			return True
# 		last_x, last_y = self.last_action
# 		for direction in [(0, 1), (1, 0), (1, 1), (1, -1)]:
# 			dire_x, dire_y = direction
# 			pre_chess = None
# 			cum_length = 0
# 			for i in range(-4, 5):
# 				cur_x, cur_y = last_x + i * dire_x, last_y + i * dire_y
# 				cur = (cur_x, cur_y)
# 				if not self.is_on_board(cur):
# 					continue
# 				cur_chess = self.whose_chess(cur)
# 				if pre_chess != cur_chess:
# 					pre_chess = cur_chess
# 					cum_length = 1
# 				else:
# 					cum_length += 1
# 					if cum_length == 5:
# 						self.state = "BLACK" if cur_chess == PIECE_BLACK else "WHITE"
# 						return True
# 		self.state = None
# 		return False
#


class Board:
	def __init__(self, size: int):
		self.size = size
		self._cells = [
			[Cell() for _ in range(self.size)]
			for _ in range(size)
		]
		self._outside_cell = Cell(piece=PIECE_OUTSIDE)
		self.turn = PIECE_BLACK
		self.last_turn = PIECE_WHITE
		self.pre_actions = []
		self.step = 0  # 当前已下的棋子数量
		self.last_action = None
		self.hall = set()
		self._zobrist_table = [
			[[getrandbits(64) for _ in range(size)] for _ in range(size)]
			for _ in range(2)
		]
		self.zobrist_key = getrandbits(64)
		self.is_terminated = False
		self.init_key()
	
	def __getitem__(self, position) -> Cell:
		if 0 <= position[0] < self.size and 0 <= position[1] < self.size:
			return self._cells[position[0]][position[1]]
		else:
			return self._outside_cell
	
	def __str__(self):
		res = f"Here is a board sized {self.size}.\n"
		res += "   "
		
		for x in range(self.size):
			res += f"{x:2}|"
		res += "\n"
		
		for x in range(self.size):
			res += f"{x:2}: "
			for y in range(self.size):
				cur_pos = (x, y)
				owner = self.whose_chess(cur_pos)
				if owner is None:
					piece = VISUAL_PIECE_EMPTY
				else:
					if self.last_action is not None and self.last_action == cur_pos:
						piece = VISUAL_PIECE_BLACK_CUR if owner == PIECE_BLACK else VISUAL_PIECE_WHITE_CUR
					else:
						piece = VISUAL_PIECE_BLACK if owner == PIECE_BLACK else VISUAL_PIECE_WHITE
				res += piece + "| "
			res += "\n"
		return res
	
	def init_key(self):
		for x in range(self.size):
			for y in range(self.size):
				for i in range(4):
					self._cells[x][y].key[i] = self.get_line_key(x, y, i)
	
	def is_on_board(self, position):
		return 0 <= position[0] < self.size and 0 <= position[1] < self.size
	
	def is_empty(self, position):
		return self.is_on_board(position) and self[position].piece == PIECE_EMPTY
	
	def whose_chess(self, position):
		piece = self[position].piece
		if piece == PIECE_EMPTY or piece == PIECE_OUTSIDE:
			return None
		return piece
	
	def get_neighbors(self, position):
		"""Returns the neighbors"""
		x, y = position
		# candidates = [
		#     (x - 2, y - 2), (x - 2, y), (x - 2, y + 2),
		#     (x - 1, y - 1), (x - 1, y), (x - 1, y + 1),
		#     (x, y - 2), (x, y - 1), (x, y + 1), (x, y + 2),
		#     (x + 1, y - 1), (x + 1, y), (x + 1, y + 1),
		#     (x + 2, y - 2), (x + 2, y), (x + 2, y + 2)
		# ]
		candidates = [
			(x - 1, y - 1), (x - 1, y), (x - 1, y + 1),
			(x, y - 1), (x, y + 1),
			(x + 1, y - 1), (x + 1, y), (x + 1, y + 1)
		]
		return [candidate for candidate in candidates if self.is_on_board(candidate)]
	
	def make_move(self, position):
		assert self.is_empty(position)
		x, y = position
		self.zobrist_key ^= self._zobrist_table[self.turn][x][y]
		self.step += 1
		self.pre_actions.append(position)
		self.last_action = position
		self._cells[x][y].piece = self.turn
		self.update_pattern(self.turn)
		self.is_terminated = PATTERN_5 in self._cells[x][y].patterns[self.turn]
		self.turn, self.last_turn = self.last_turn, self.turn
		self.update_hall()
	
	def withdraw(self):
		assert self.whose_chess(self.last_action) == self.last_turn
		last_x, last_y = self.last_action
		self.zobrist_key ^= self._zobrist_table[self.last_turn][last_x][last_y]
		self._cells[last_x][last_y].piece = PIECE_EMPTY
		self.update_pattern(PIECE_EMPTY)
		self.is_terminated = False
		self.turn, self.last_turn = self.last_turn, self.turn
		self.revert_hall()
		self.pre_actions.pop()
		self.step -= 1
		self.last_action = self.pre_actions[-1] if self.step > 0 else None
	
	def update_hall(self):
		for neighbor_pos in self.get_neighbors(self.last_action):
			neighbor_cell = self._cells[neighbor_pos[0]][neighbor_pos[1]]
			neighbor_cell.num_of_neighbors += 1
			if neighbor_cell.piece == PIECE_EMPTY:
				self.hall.add(neighbor_pos)
		self.hall.discard(self.last_action)
	
	def revert_hall(self):
		for neighbor_pos in self.get_neighbors(self.last_action):
			neighbor_cell = self._cells[neighbor_pos[0]][neighbor_pos[1]]
			neighbor_cell.num_of_neighbors -= 1
			if neighbor_cell.num_of_neighbors == 0 and neighbor_cell.piece == PIECE_EMPTY:
				self.hall.discard(neighbor_pos)
		if self.step != 1:
			self.hall.add(self.last_action)
	
	def get_line_key(self, x, y, index):
		dx, dy = DIRECTIONS[index]
		key = self[(x - 4 * dx, y - 4 * dy)].piece\
			  | self[(x - 3 * dx, y - 3 * dy)].piece << 2\
			  | self[(x - 2 * dx, y - 2 * dy)].piece << 4\
			  | self[(x - 1 * dx, y - 1 * dy)].piece << 6\
			  | self[(x + 1 * dx, y + 1 * dy)].piece << 8\
			  | self[(x + 2 * dx, y + 2 * dy)].piece << 10\
			  | self[(x + 3 * dx, y + 3 * dy)].piece << 12\
			  | self[(x + 4 * dx, y + 4 * dy)].piece << 14
		return key
	
	def update_pattern(self, piece):
		last_x, last_y = self.last_action
		for i in range(4):
			dx, dy = DIRECTIONS[i]
			for j in (-4, -3, -2, -1, 1, 2, 3, 4):
				cur_x = last_x + j * dx
				cur_y = last_y + j * dy
				if 0 <= cur_x < self.size and 0 <= cur_y < self.size:
					cell = self._cells[cur_x][cur_y]
					new_key = cell.key[i] & ~(0b11 << KEY_OFFSET[-j]) | (piece << KEY_OFFSET[-j])
					cell.key[i] = new_key
					cell.patterns[0][i] = KP_TABLE[new_key][0]
					cell.patterns[1][i] = KP_TABLE[new_key][1]
	
	def restart(self):
		while self.pre_actions:
			self.withdraw()


def main():
	seed(1234)
	board = Board(20)
	board.make_move((10, 10))
	board.withdraw()
	print(board.hall)
	board = Board(20)
	print(board.zobrist_key)
	board.make_move((0, 0))
	board.make_move((1, 0))
	
	board.make_move((0, 1))
	board.make_move((1, 1))
	board.make_move((3, 2))
	board.make_move((1, 2))
	board.make_move((0, 3))
	board.make_move((1, 3))
	board.make_move((0, 4))
	print(board.zobrist_key)
	board.make_move((1, 5))
	
	print(board)
	print(board.hall)
	print(len(board.hall))
	print(board.zobrist_key)
	board.withdraw()
	print(board)
	print(board.hall)
	print(len(board.hall))
	print(board.zobrist_key)


if __name__ == "__main__":
	main()
