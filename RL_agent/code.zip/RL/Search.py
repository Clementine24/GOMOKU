# import random

from Board import Board
from util import *
from time import time
from Tables import PS_TABLE
from copy import deepcopy
from random import choice, seed, randint, random
import copy


class MinimaxSearchAgent:
    """Used as Environment"""
    def __init__(self, board: Board, min_depth=MIN_DEPTH, max_depth=MAX_DEPTH):
        self.board = board
        self.transposition_table = {}
        self.hist_table = {}
        self.min_depth = min_depth
        self.max_depth = max_depth
        self.hit = 0
        self.stop_thinking = False
        self.losing_actions = set()
        self.root_actions = None
        self.start_time = 0
        self.time_left = TIME_MATCH
        self.time_turn = TIME_TURN
        self.search_count = 1000
    
    def get_time(self):
        return time() - self.start_time
    
    def get_stop_time(self):
        return self.time_turn if self.time_turn < self.time_left / 7 else self.time_left / 7
    
    def get_position_score(self, position):
        my, op = self.board.turn, self.board.last_turn
        patterns = self.board[position].patterns
        scores = [
            PS_TABLE[patterns[0][0]][patterns[0][1]][patterns[0][2]][patterns[0][3]],
            PS_TABLE[patterns[1][0]][patterns[1][1]][patterns[1][2]][patterns[1][3]],
        ]
        if scores[my] >= 200 or scores[op] >= 200:
            return 2 * scores[my] if 2 * scores[my] > scores[op] else scores[op]
        else:
            return 2 * scores[my] + scores[op]
    
    def get_evaluated_score(self):
        my, op = self.board.turn, self.board.last_turn
        my_patterns_counts = [0 for _ in range(8)]
        op_patterns_counts = [0 for _ in range(8)]
        
        for position in self.board.hall:
            cur_pos_patterns = self.board[position].patterns
            my_pre_S4 = my_patterns_counts[PATTERN_S4]
            op_pre_5 = op_patterns_counts[PATTERN_5]
            op_pre_L4 = op_patterns_counts[PATTERN_L4]
            for i in range(4):
                my_patterns_counts[cur_pos_patterns[my][i]] += 1
                op_patterns_counts[cur_pos_patterns[op][i]] += 1
            if my_patterns_counts[PATTERN_S4] - my_pre_S4 >= 2:
                my_patterns_counts[PATTERN_S4] = my_pre_S4
                my_patterns_counts[PATTERN_L4] += 1
            if op_patterns_counts[PATTERN_5] - op_pre_5 >= 2:
                op_patterns_counts[PATTERN_5] = op_pre_5 + 1
            if op_patterns_counts[PATTERN_L4] - op_pre_L4 >= 2:
                op_patterns_counts[PATTERN_L4] = op_pre_L4 + 1
        
        if my_patterns_counts[PATTERN_5] >= 1:
            return WIN_SCORE
        if op_patterns_counts[PATTERN_5] >= 2:
            return LOSE_SCORE
        if op_patterns_counts[PATTERN_5] == 0 and my_patterns_counts[PATTERN_L4] >= 1:
            return WIN_SCORE
        
        my_score = 0
        op_score = 0
        for i in range(8):
            my_score += my_patterns_counts[i] * PATTERN_SCORES[i]
            op_score += op_patterns_counts[i] * PATTERN_SCORES[i]
        return int(1.1 * my_score) - op_score
    
    def get_ordered_actions(self):
        my, op = self.board.turn, self.board.last_turn
        actions = [Action(position, self.get_position_score(position)) for position in self.board.hall]
        actions.sort(key=lambda action: action.value, reverse=True)
        highest_scores = actions[0].value
        
        # 情况一：我方连五点、对方连五点：直接采用，不考虑其他点
        # 情况二：双方无连五点，但我方有活四点，直接采用，不考虑其他点
        if highest_scores >= 2400:
            return [actions[0].position]
        
        # 情况三：我方冲四活三点
        # if highest_scores >= 2000 and actions[1].value < 1200:
        #     return [actions[0].position]
        
        # 情况四：双方无连五点，我方也无活四点，且对方有活四点，分情况讨论
        # 1. 若对方棋型为__XXX__，有双活四点，必须选一个防守，或选择我方冲四点进攻
        # 2. 若对方棋型为_X_XX__，有一个活四点和两个冲四点，可以任选一个点防守，或选择我方冲四点进攻
        count = 0
        final_actions = []
        if highest_scores == 1200:
            for i in range(len(actions)):
                if actions[i].value == 1200:
                    count += 1
                    final_actions.append(actions[i].position)
                else:
                    break
            
            if count > 1:
                for i in range(count, len(actions)):
                    cur_pos = self.board[actions[i].position]
                    if PATTERN_S4 in cur_pos.patterns[my]:
                        count += 1
                        final_actions.append(actions[i].position)
                        if count >= MAX_ACTION_NUM:
                            break
                return final_actions
            else:
                for i in range(count, len(actions)):
                    cur_pos = self.board[actions[i].position]
                    if PATTERN_S4 in cur_pos.patterns[my] or\
                            (PATTERN_S4 in cur_pos.patterns[op] and
                             distance(actions[0].position, actions[i].position) in {2, 3}):
                        count += 1
                        final_actions.append(actions[i].position)
                        if count >= MAX_ACTION_NUM:
                            break
                return final_actions
        
        # 情况五：对方冲四活三点
        # if highest_scores >= 1000:
        #     final_actions.append(actions[0].action)
        #     for i in range(count, len(actions)):
        #         cur_pos = self.board[actions[i].action]
        #         if PATTERN_S4 in cur_pos.patterns[my]:
        #             count += 1
        #             final_actions.append(actions[i].action)
        #             if count >= MAX_ACTION_NUM:
        #                 break
        #     return final_actions
        # if highest_scores >= 400:
        #     return [actions[0].action]
        # if highest_scores >= 200:
        #     final_actions.append(actions[0].action)
        #     for i in range(count, len(actions)):
        #         cur_pos = self.board[actions[i].action]
        #         if PATTERN_S4 in cur_pos.patterns[my]:
        #             count += 1
        #             final_actions.append(actions[i].action)
        #             if count >= MAX_ACTION_NUM:
        #                 break
        #     return final_actions
        return [x.position for x in actions[:MAX_ACTION_NUM]]
    
    def record_tt(self, depth, value, flag):
        """将搜索完毕的深度、评估值、哈希标志记录到置换表"""
        item = self.transposition_table.get(self.board.zobrist_key, None)
        if item is None or item[0] <= depth:
            self.transposition_table[self.board.zobrist_key] = (depth, value, flag)
    
    def probe_tt(self, depth, alpha, beta):
        """探查置换表，若发现深度更深的，则返回评估值"""
        item = self.transposition_table.get(self.board.zobrist_key, None)
        if item is None:
            return None
        if item[2] == HASH_EXACT and (item[1] == WIN_SCORE or item[1] == LOSE_SCORE):
            return item[1]
        if item[0] >= depth:
            if item[2] == HASH_EXACT:
                return item[1]
            elif item[2] == HASH_ALPHA and item[1] <= alpha:
                return alpha
            elif item[2] == HASH_BETA and item[1] >= beta:
                return beta
        return None
    
    def alpha_beta_search(self, alpha, beta, depth):
        """非根节点的 Alpha-Beta 搜索"""
        self.search_count -= 1
        if self.search_count == 0:
            self.search_count = 1000
            if self.get_time() + 0.1 > self.get_stop_time():
                self.stop_thinking = True
                return alpha
        
        # 第一步：探查置换表。若探查到，直接返回表中的值
        hash_flag = HASH_ALPHA  # 初始化哈希标志
        value = self.probe_tt(depth, alpha, beta)  # 探查置换表
        if value is not None:
            self.hit += 1  # 探查到
            return value
        
        # 第二步：终止判断。若终止，不再进行搜索
        if self.board.is_terminated:  # 对手上一步棋成五，对局结束，返回失败的得分
            return LOSE_SCORE
        if depth == 0:  # 深度到达上限，评估棋盘，记录到置换表
            value = self.get_evaluated_score()
            self.record_tt(depth, value, HASH_EXACT)
            return value
        
        # 第三步：极小极大搜索
        best_action = None
        best_value = LOSE_SCORE
        found_pv = False
        
        actions = []
        cur_index = -1
        cur_action = self.hist_table.get(self.board.zobrist_key, None)
        if cur_action is None:
            actions = self.get_ordered_actions()
            cur_index = 0
        while cur_index < len(actions):
            if cur_index != -1:
                cur_action = actions[cur_index]
            self.board.make_move(cur_action)
            if found_pv and alpha + 1 < beta:
                cur_value = -self.alpha_beta_search(-alpha - 1, -alpha, depth - 1)
                if alpha < cur_value < beta:
                    cur_value = -self.alpha_beta_search(-beta, -alpha, depth - 1)
            else:
                cur_value = -self.alpha_beta_search(-beta, -alpha, depth - 1)
            self.board.withdraw()
            if self.stop_thinking:
                return best_value
            if cur_value >= beta:
                self.record_tt(depth, beta, HASH_BETA)
                self.hist_table[self.board.zobrist_key] = cur_action
                return beta
            if cur_value > best_value:
                best_action = cur_action
                best_value = cur_value
                if cur_value > alpha:
                    hash_flag = HASH_EXACT
                    alpha = cur_value
                    found_pv = True
            if cur_index == -1:
                actions = self.get_ordered_actions()
                if cur_action in actions:
                    actions.remove(cur_action)
            cur_index += 1
        
        self.record_tt(depth, best_value, hash_flag)  # 搜索完毕，记录到置换表
        self.hist_table[self.board.zobrist_key] = best_action
        return best_value
    
    def root_search(self, alpha, beta, depth):
        """根节点的搜索（相比非根节点，额外记录控制迭代加深的信息）"""
        if depth == self.min_depth:  # 第一次进入搜索
            self.root_actions = [Action(action, 0) for action in self.get_ordered_actions()]
            if len(self.root_actions) == 1:  # 只存在一个可行着法，直接采用并返回
                self.stop_thinking = True
                return self.root_actions[0].position
        else:
            self.root_actions.sort(key=lambda action: action.value, reverse=True)
        best_action = self.root_actions[0].position  # 选择第一个点作为初始点。若每个点都是必败点，则只好选择第一个点
        found_pv = False  # new
        for i in range(len(self.root_actions)):
            cur_action = self.root_actions[i].position
            if cur_action not in self.losing_actions:
                self.board.make_move(cur_action)
                if found_pv and alpha + 1 < beta:
                    cur_value = -self.alpha_beta_search(-alpha - 1, -alpha, depth - 1)
                    if alpha < cur_value < beta:
                        cur_value = -self.alpha_beta_search(-beta, -alpha, depth - 1)
                else:
                    cur_value = -self.alpha_beta_search(-beta, -alpha, depth - 1)
                self.board.withdraw()
                self.root_actions[i].value = cur_value
                if self.stop_thinking:
                    break
                if cur_value <= LOSE_SCORE:  # 该着法必然会导致失败，之后深度加深的搜索无须再考虑之
                    self.losing_actions.add(cur_action)
                if cur_value > alpha:
                    alpha = cur_value
                    found_pv = True
                    best_action = cur_action
                    if cur_value >= WIN_SCORE:  # 该走法已然导致胜利，直接返回该走法
                        self.stop_thinking = True
                        return best_action
        return best_action
    
    def solve(self):
        """主要搜索函数：从棋盘返回动作"""
        self.start_time = time()
        best_action = None  # AI思考的最佳点
        step = self.board.step
        if step == 0:
            best_action = (self.board.size // 2, self.board.size // 2)
        elif step == 1:
            first_x, first_y = self.board.pre_actions[0]
            while True:
                rand_dx = randint(-step, step)
                rand_dy = randint(-step, step)
                cur_pos = (first_x + rand_dx, first_y + rand_dy)
                if self.board.is_empty(cur_pos):
                    break
            best_action = cur_pos
        else:
            self.stop_thinking = False  # 初始化迭代加深停止标志
            self.losing_actions = set()  # 初始化必败点集合（浅层必败点，深层不必再搜索）
            for search_depth in range(self.min_depth, self.max_depth + 1, 2):  # 迭代加深循环
                best_action = self.root_search(LOSE_SCORE - 1, WIN_SCORE, search_depth)  # 对每个深度进行根节点搜索
                used_time = self.get_time()
                if self.stop_thinking:
                    break
                # if self.stop_thinking or (search_depth >= 8 and used_time * 10 >= self.get_stop_time()):
                #     # 浅层搜索已然找到必胜法，或时间不足以进行下一轮加深搜索，则停止搜索，直接返回
                #     break
        self.time_left -= time() - self.start_time
        return best_action


class Environment:
    """Used by the VFA RL Agent"""
    def __init__(self, board: Board):
        self.board = board
        self.ab_agent = MinimaxSearchAgent(board, max_depth=8)
    
    def get_feedback(self, my_action):
        self.board.make_move(my_action)
        print("Agent's turn: ")
        print(self.board)
        if self.board.is_terminated:
            return WIN_SCORE
        
        op_action = self.ab_agent.solve()
        self.board.make_move(op_action)
        print("Feedback: ")
        print(self.board)
        if self.board.is_terminated:
            return LOSE_SCORE
        return 0
        
        
def get_legal_actions(board: Board):
    """Used by tableau RL Agent"""
    if board.is_terminated:
        return None
    if board.step == 0:
        return [(board.size // 2, board.size // 2)]
    return list(board.hall)


def get_envir_feedback(board: Board, my_action):
    """Used by tableau RL Agent"""
    board.make_move(my_action)
    if board.step != 1:
        pre_pre_action = board.pre_actions[-2]
        op_pattern = board._cells[pre_pre_action[0]][pre_pre_action[1]].patterns[board.turn]
        if PATTERN_L4 in op_pattern or PATTERN_S4 in op_pattern:
            return 0.2 * LOSE_SCORE
        if PATTERN_L3 in op_pattern:
            return 0.04 * LOSE_SCORE
    my_pattern = board._cells[board.last_action[0]][board.last_action[1]].patterns[board.last_turn]
    if PATTERN_L4 in my_pattern:
        return 0.2 * WIN_SCORE
    if board.is_terminated:
        return WIN_SCORE
    rand = random()
    if rand < 1:
        op_action = MinimaxSearchAgent(board, max_depth=1).solve()
    elif rand < 0.7:
        op_action = MinimaxSearchAgent(board, max_depth=2).solve()
    elif rand < 0.9:
        op_action = MinimaxSearchAgent(board, max_depth=3).solve()
    else:
        op_action = MinimaxSearchAgent(board, max_depth=4).solve()
    board.make_move(op_action)
    return LOSE_SCORE if board.is_terminated else 0


class State:
    """Used by the tableau RL Agent"""
    def __init__(self, board=None, Q_values=None):
        if Q_values is None:
            actions = get_legal_actions(board)
            self.Q_values = dict.fromkeys(actions, 0) if actions is not None else {}
        elif board is None:
            self.Q_values = Q_values
        else:
            raise Exception

    def __repr__(self):
        return str(self.Q_values)


class RLSearchAgent:
    """Tableau RL Agent"""
    def __init__(self, board, max_simulations=MAX_SIMULATIONS):
        self.main_board = board
        self.explored_states = {}
        self.start_state = None
        self.max_simulations = max_simulations
    
    def random_policy(self):
        legal_actions = get_legal_actions(self.main_board)
        if legal_actions is None:
            return None
        return choice(legal_actions)
    
    @staticmethod
    def e_greedy_policy(state: State, epsilon=EPSILON):
        if random() < epsilon:
            return max(state.Q_values.items(), key=lambda x: x[1])[0]
        else:
            return choice(list(state.Q_values.keys()))
    
    def Q_learning(self, alpha=ALPHA, gamma=GAMMA):
        for i in range(self.max_simulations):
            board_copy = deepcopy(self.main_board)
            cur_state = self.start_state
            while True:
                action = self.e_greedy_policy(cur_state)
                reward = get_envir_feedback(board_copy, action)
                new_state = self.explored_states.setdefault(board_copy.zobristKey, State(board_copy))
                # if reward == WIN_SCORE or reward == LOSE_SCORE:
                if reward != 0:
                    cur_state.Q_values[action] = reward
                    break
                else:
                    cur_state.Q_values[action] = (1 - alpha) * cur_state.Q_values[action] +\
                                                 alpha * (reward + gamma * max(new_state.Q_values.values()))
                cur_state = new_state
    
    def solve(self):
        if self.main_board.step == 0:
            best_action = (10, 10)
        elif self.main_board.step == 1:
            first_x, first_y = self.main_board.lastAction
            while True:
                rand_dx = randint(-1, 1)
                rand_dy = randint(-1, 1)
                cur_pos = (first_x + rand_dx, first_y + rand_dy)
                if self.main_board.isEmpty(cur_pos):
                    break
            best_action = cur_pos
        else:
            self.start_state = self.explored_states.setdefault(self.main_board.zobristKey, State(self.main_board))
            self.Q_learning()
            best_action = max(self.start_state.Q_values.items(), key=lambda x: x[1])[0]
        return best_action


class VFAagent:
    """Final VFA Agent"""
    def __init__(self, board):
        self.board = board
        self.explored_states = {}
        # self.weight = [0 for _ in range(14)]
        # self.weight = [0,0.5,1,2,4,8,10,
        #                -0,-0.5,-1,-2,-4,-8,-10]
        # training by 4-depth minimax
        # self.weight = [0.18407139431758004, 0.5958560711185785, 0.9370996803219867, 1.8355108960457565, 3.349170154631613, 6.736760595145956, 7.997078479993291, -0.22088567318109606, -0.7150272853422942, -1.124519616386384, -2.2026130752549076, -4.019004185557935, -8.084112714175147, -9.596494175991948]
        # training by 6-depth minimax
        # self.weight = [0.26212122507086705, 0.6918951464146911, 0.9422843802126167, 1.6725598041787508, 3.491701723385618,
        #  6.664771366781248, 7.997328226158064, -0.31454547008504047, -0.8302741756976293, -1.13074125625514,
        #  -2.007071765014501, -4.190042068062741, -7.997725640137498, -9.596793871389677]
        # training by 4-depth but AB first
        # self.weight = [0.018465005699938634, 0.7925934085749675, 0.8378738431349925, 2.2761288189136106, 3.337926113262407, 6.800132699964591, 7.596142768144209, -0.022158006839926362, -0.951112090289961, -1.005448611761991, -2.7313545826963326, -4.005511335914888, -8.160159239957508, -9.11537132177305]
        # training by 4-depth after update
        self.weight = [0.19747237048783434, 0.5564943364458053, 0.8967874637378702, 1.8434082265627805, 3.3441397683462815, 6.788994625968954, 7.9345538766175805, -0.2369668445854012, -0.6677932037349663, -1.0761449564854442, -2.2120898718753366, -4.012967722015538, -8.146793551162745, -9.521464651941097]
        self.alpha = ALPHA

        # with open("weight.txt", "r") as f:     # store the weight after iteration
        #     self.weight = eval(f.readline())
        # with open("zobkey.txt","r") as f:     # use the state detected
        #     self.explored_states = eval(f.readline())
        # f.close()

    def get_legal_actions(self, board: Board):
        if board.is_terminated:
            return None
        if board.step == 0:
            return [(board.size // 2, board.size // 2)]
        return list(board.hall)             # all position in radius 1

    # def add_explored_states(self, board):  # use the number of chess type of position empty
    #     feature = [0 for _ in range(16)]
    #     my = board.turn
    #     op = 1 - my
    #     for position in board.hall:
    #         cur_pos_patterns = board[position].patterns
    #         for i in range(4):
    #             feature[cur_pos_patterns[my][i]] += 1
    #             feature[cur_pos_patterns[op][i]+8] += 1
    #     self.explored_states[board.zobrist_key] = feature

    def add_explored_states(self, board, myturn=True):    # use the number of chess type of position nonempty
        '''
        Input a board and the player who play chess in this turn,
        extract and store the feature vector of the chessboard
        '''
        feature = [0 for _ in range(14)]
        if myturn:
            my = board.turn
            op = 1 - my
        else:
            op = board.turn
            my = 1 - op
        for x in range(BOARD_SIZE):
            for y in range(BOARD_SIZE):
                if board.is_empty((x, y)):     # find nonempty position
                    continue
                cur_pos_patterns = board[(x, y)].patterns
                who = board.whose_chess((x, y))
                if who == my:
                    for i in range(4):
                        if cur_pos_patterns[my][i] != 0:
                            feature[cur_pos_patterns[my][i]-1] += 1
                else:
                    for i in range(4):
                        if cur_pos_patterns[op][i] != 0:
                            feature[cur_pos_patterns[op][i]+6] += 1
        self.explored_states[board.zobrist_key] = feature    # store feature vector

    def calculate_score(self, feature):
        '''
        Input a feature,
        return the approximate linear value
        '''
        func = lambda x, y: x * y
        value = sum(list(map(func, feature, self.weight)))
        return value

    def update_weight(self, feature1, feature2, reward=0):
        '''
        Input two feature of different state and the reward of transition
        Update the weight of score function
        '''
        self.alpha = self.alpha * 0.9
        func = lambda x, y: x + y
        value1 = self.calculate_score(feature1)
        value2 = self.calculate_score(feature2)
        coefficient = GAMMA * value2 - value1
        step = [self.alpha * coefficient * i for i in feature1]
        self.weight = list(map(func, self.weight, step))
        for i in range(7):
            self.weight[i] = -self.weight[i+7]/1.2
        if reward != 0:     # Stipulate that can only get rewards when exit the game, and the Q value of the next state is 0
            coefficient = 2*reward - value2
            step = [self.alpha * coefficient * i for i in feature2]
            self.weight = list(map(func, self.weight, step))
            for i in range(7):
                self.weight[i] = -self.weight[i + 7] / 1.2

    def choose_action(self, board, ran = True):
        '''
        Input a board,
        Return an action according to epsilon-greedy policy
        '''
        if not bool(board.hall):      # an empty board
            board.make_move((BOARD_SIZE // 2, BOARD_SIZE // 2))
            self.add_explored_states(board, myturn=False)
            board.withdraw()
            return (BOARD_SIZE // 2, BOARD_SIZE // 2)
        if ran and random() <= EPSILON:
            action = choice(list(board.hall))
            board.make_move(action)
            self.add_explored_states(board, myturn=False)
            board.withdraw()
            return action
        action_return = {}
        for position in board.hall:
            board.make_move(position)
            if board.is_terminated:
                board.withdraw()
                return position
            ab_agent = MinimaxSearchAgent(board, max_depth=4)    # virtual environment
            environ_action = ab_agent.solve()
            board.make_move(environ_action)
            if board.is_terminated:
                board.withdraw()
                board.withdraw()
                continue
            action_return[position] = board.zobrist_key
            if board.zobrist_key not in self.explored_states:
                self.add_explored_states(board)
            board.withdraw()
            board.withdraw()
        if not bool(action_return):      # No find any position we can move, in other word, we will LOSE. Just take a move
            action = choice(list(board.hall))
            board.make_move(action)
            self.add_explored_states(board, myturn=False)
            board.withdraw()
            return action
        best_action = max(action_return.keys(),
                          key=lambda a: self.calculate_score(self.explored_states[action_return[a]]))
        return best_action

    def generate(self):       # train every step
        if self.board.zobrist_key not in self.explored_states:
            self.add_explored_states(self.board)
        for i in range(MAX_SIMULATIONS):
            simuboard = copy.deepcopy(self.board)
            while True:      # An episode
                action = self.choose_action(simuboard)
                feature1 = self.explored_states[simuboard.zobrist_key]
                simuboard.make_move(action)
                if simuboard.is_terminated:
                    if simuboard.zobrist_key not in self.explored_states:
                        self.add_explored_states(simuboard, myturn=False)
                    feature2 = self.explored_states[simuboard.zobrist_key]
                    self.update_weight(feature1, feature2, WIN_REWARD)
                    break
                abagent = MinimaxSearchAgent(simuboard, max_depth=4)
                environ_action = abagent.solve()
                simuboard.make_move(environ_action)
                if simuboard.zobrist_key not in self.explored_states:
                    self.add_explored_states(simuboard)
                feature2 = self.explored_states[simuboard.zobrist_key]
                reward = 0 if not simuboard.is_terminated else -WIN_REWARD
                self.update_weight(feature1, feature2, reward)
                if simuboard.is_terminated:
                    break

    def solve(self):
        if self.board.is_terminated:
            return None
        # self.generate()    # If training, call this function. Otherwise, do not need to simulate.
        return self.choose_action(self.board, ran=False)    # Choose an action only by exploitation.


def main():
    seed(1234)
    board = Board(20)
    # environment = Environment(board)
    print("Environment is ready!")
    rl_black_agent = VFAagent(board)
    # ab_black_agent = MinimaxSearchAgent(board,max_depth=8)
    ab_white_agent = MinimaxSearchAgent(board, max_depth=2)
    print("Agent is ready!")
    
    print(board)
    print("Learning begins!")
    while True:
        start = time()
        agent_action = rl_black_agent.solve()
        # action = ab_black_agent.solve()
        board.make_move(agent_action)
        print(board)
        print(time() - start)
        print(rl_black_agent.weight)
        if board.is_terminated:
            break
        # if agent_action is None:
        #     break
        
        # environment.get_feedback(agent_action)
        action = ab_white_agent.solve()
        board.make_move(action)
        print(board)
        if board.is_terminated:
            break
        # agent_action = rl_black_agent.solve()
        # # action = ab_black_agent.solve()
        # board.make_move(agent_action)
        # print(board)
        # print(time() - start)
        # print(rl_black_agent.weight)
        # if board.is_terminated:
        #     break
    # with open("weight.txt", "w") as f:
    #     f.write(str(rl_black_agent.weight))
    # with open("zobkey.txt", "w") as f:
    #     f.write(str(rl_black_agent.explored_states))
    if board.turn == PIECE_BLACK:
        print("Agent loses...")
    else:
        print("Agent wins!!!")


if __name__ == "__main__":
    main()
    