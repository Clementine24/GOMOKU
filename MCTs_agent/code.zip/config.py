import math


BOARD_WIDTH = 20
BOARD_HEIGHT = 20
EMPTY_CHESS = '·'
BLACK_CHESS = 'o'
WHITE_CHESS = 'x'
BLACK_CHESS_CUR = 'O'
WHITE_CHESS_CUR = 'X'
EMPTY = 0
BLACK = 1
WHITE = 2
NEIGHBOR_RADIUS = 1
MAX = 1
MIN = 2
R = 0.05
C = math.sqrt(2)
TIME_LIMIT = 10
MAX_SIMULATIONS = 1000


def get_opponent(player):
    return 3 - player


def get_my_score(score_table, player, turn):
    if turn == player:
        return (1 + R) * score_table[player] - score_table[get_opponent(player)]
    else:
        return score_table[player] - (1 + R) * score_table[get_opponent(player)]



