from Board import Board
from config import *
import random
from Evaluator import Evaluator


class Node:
    """Node for NegaMax Search"""

    def __init__(self, board: Board, board_score=0, is_leaf=False):
        self._board = board  # 该结点落子前的棋盘（外界不需访问）
        self.rule = "max" if self._board.turn == BLACK else "min"  # 该结点的规则
        self.board_score = board_score
        self.value = board_score if self.rule == "max" else -board_score  # 传入结点棋盘的评估值，计算结点分数，为±inf代表对局结束
        self.is_leaf = is_leaf

    def get_board_score(self, eval_func):
        score_table = eval_func.get_board_score(self._board)
        return score_table[BLACK] - 0.9 * score_table[WHITE]

    def get_actions(self):
        if not self._board.hall:
            return [(self._board.size // 2, self._board.size // 2)]
        return self._board.hall

    def get_ordered_actions(self, eval_func: Evaluator()):
        actions = list(self.get_actions())
        player = BLACK if self.rule == "max" else WHITE
        opponent = WHITE if player == BLACK else BLACK
        important_actions = []
        important_board_scores = []
        max_importance_level = 0
        for action in actions:

            # 单点分数判断，若超过一定分数，则为重要点，必须立刻抢占
            action_score = eval_func.get_position_score(self._board, action)
            if action_score[player] < 2 * Evaluator.score_table['l3'] \
                    and action_score[opponent] < 2 * Evaluator.score_table['l3']:
                continue  # 无特殊棋形，跳过
            if action_score[player] >= Evaluator.score_table['five']:  # 该步我方得分为正无穷，是我方胜利点，立即采用
                # return [(action, float("inf") if player == BLACK else float("-inf"))]
                return [(action, Evaluator.score_table['five'] if player == BLACK else Evaluator.score_table['five'])]
                # important_actions.append(action)
                # important_board_scores.append(float("inf") if player == BLACK else float("-inf"))
                # break

            elif action_score[opponent] >= Evaluator.score_table['five']:  # 该步对方得分正无穷，是对方胜利点，应优先抢占
                if max_importance_level > 9:
                    continue
                elif max_importance_level < 9:
                    max_importance_level = 9
                    important_actions = []
                    important_board_scores = []
                board_score = self.get_successor(action, eval_func=eval_func).board_score
                self.revert()
                important_actions.append(action)
                important_board_scores.append(board_score)

            elif action_score[player] >= Evaluator.score_table['l4']:  # 该步我方得分超过活四，是我方活四点，应优先采用
                if max_importance_level > 8:
                    continue
                elif max_importance_level < 8:
                    max_importance_level = 8
                    important_actions = []
                    important_board_scores = []
                board_score = self.get_successor(action, eval_func=eval_func).board_score
                self.revert()
                important_actions.append(action)
                important_board_scores.append(board_score)
                # important_board_scores.append(Evaluator.score_table['l4']
                #                               if player == BLACK else -Evaluator.score_table['l4'])

            elif action_score[opponent] >= Evaluator.score_table['l4']:  # 该步对方得分超过活四，是对方活四点，应优先考虑
                if max_importance_level > 7:
                    continue
                max_importance_level = 7
                important_actions = []
                important_board_scores = []
                board_score = self.get_successor(action, eval_func=eval_func).board_score
                self.revert()
                important_actions.append(action)
                important_board_scores.append(board_score)

            elif action_score[player] >= 2 * Evaluator.score_table['s4']:  # 该步我方得分超过双眠四，是我方双眠四点，应优先考虑
                if max_importance_level > 6:
                    continue
                max_importance_level = 6
                important_actions = []
                important_board_scores = []
                board_score = self.get_successor(action, eval_func=eval_func).board_score
                self.revert()
                important_actions.append(action)
                important_board_scores.append(board_score)

            elif action_score[opponent] >= 2 * Evaluator.score_table['s4']:  #
                if max_importance_level > 5:
                    continue
                max_importance_level = 5
                important_actions = []
                important_board_scores = []
                board_score = self.get_successor(action, eval_func=eval_func).board_score
                self.revert()
                important_actions.append(action)
                important_board_scores.append(board_score)

            elif action_score[player] >= Evaluator.score_table['s4'] + Evaluator.score_table['l3']:
                if max_importance_level > 4:
                    continue
                max_importance_level = 4
                important_actions = []
                important_board_scores = []
                board_score = self.get_successor(action, eval_func=eval_func).board_score
                self.revert()
                important_actions.append(action)
                important_board_scores.append(board_score)

            elif action_score[opponent] >= Evaluator.score_table['s4'] + Evaluator.score_table['l3']:
                if max_importance_level > 3:
                    continue
                max_importance_level = 3
                important_actions = []
                important_board_scores = []
                board_score = self.get_successor(action, eval_func=eval_func).board_score
                self.revert()
                important_actions.append(action)
                important_board_scores.append(board_score)

            elif action_score[player] >= 2 * Evaluator.score_table['l3']:
                if max_importance_level > 2:
                    continue
                max_importance_level = 2
                important_actions = []
                important_board_scores = []
                board_score = self.get_successor(action, eval_func=eval_func).board_score
                self.revert()
                important_actions.append(action)
                important_board_scores.append(board_score)

            elif action_score[opponent] >= 2 * Evaluator.score_table['l3']:
                if max_importance_level > 1:
                    continue
                max_importance_level = 1
                important_actions = []
                important_board_scores = []
                board_score = self.get_successor(action, eval_func=eval_func).board_score
                self.revert()
                important_actions.append(action)
                important_board_scores.append(board_score)

        if important_actions:  # 如果有重要点，直接返回重要点和其棋盘分（排序后）
            return sorted(zip(important_actions, important_board_scores),
                          key=lambda x: x[1],
                          reverse=self.rule == "max")

        # 棋盘分数判断，若没有重要点，以全棋盘得分作为动作的排序依据
        board_scores = []
        for action in actions:
            board_score = self.get_successor(action, eval_func=eval_func).board_score
            self.revert()
            board_scores.append(board_score)
        return sorted(zip(actions, board_scores),
                      key=lambda x: x[1],
                      reverse=self.rule == "max")  # 返回已记录的(动作, 棋盘分)对，根据结点类型选择正逆序排序

        #     self._board.move(action)
        #     score_table = eval_func.get_board_score(self._board)
        #     self._board.withdraw()
        #     board_score = score_table[BLACK] - score_table[WHITE]
        #     if board_score == (float("inf") if self.rule == "max" else float("-inf")):
        #         return [(action, board_score)]
        #     board_scores.append(board_score)
        # return sorted(zip(actions, board_scores),
        #               key=lambda x: x[1],
        #               reverse=self.rule == "max")[:15]

    def get_successor(self, action, board_score=None, eval_func=None):
        self._board.move(action)
        if board_score is None:  # 没有给board_score赋值，说明是在get_ordered_actions()中调用，为结点计算估值
            board_score = self.get_board_score(eval_func)
        return Node(  # 若给参数board_score赋了值，说明是在搜索算法中调用，不用重新计算
            board=self._board,
            board_score=board_score,
            is_leaf=(board_score >= Evaluator.score_table['five'] or board_score <= -Evaluator.score_table['five'])
        )

    def revert(self):
        self._board.withdraw()


# class Node:
#     """Node for Minimax Search (Stop updating)"""
#     def __init__(self, board: Board):
#         self._board = board  # 该结点落子前的棋盘（外界不需访问）
#         self.rule = "max" if self._board.turn == BLACK else "min"  # 该结点的规则
#         self.is_leaf = self._board.check_if_terminated()  # 对局结束的结点，标记为叶结点
#         self.state = self._board.state  # 棋盘的状态（黑胜/白胜/和局/未分胜负）
#
#     def get_value(self, eval_func):
#         score_table = eval_func.get_board_score(self._board)
#         return score_table[BLACK] - score_table[WHITE]
#
#     def get_actions(self):
#         if not self._board.hall:
#             return [(self._board.size // 2, self._board.size // 2)]
#         return self._board.hall
#
#     def get_ordered_actions(self, eval_func):
#         actions = list(self.get_actions())
#         if len(actions) == 1:
#             return actions
#         action_eval_values = []
#         for action in actions:
#             self._board.move(action)
#             score_table = eval_func.get_board_score(self._board)
#             action_eval_values.append(score_table[BLACK] - score_table[WHITE])
#             self._board.withdraw()
#         return sorted(actions,
#                       key=lambda x: action_eval_values[actions.index(x)],
#                       reverse=self.rule == "max")[:15]
#
#     def get_successor(self, action):
#         self._board.move(action)
#         return Node(board=self._board)
#
#     def revert(self):
#         self._board.withdraw()
#
#     def get_successors(self):
#         successors = []
#         for action in self.get_actions():
#             board_copy = copy.deepcopy(self._board)  # 深拷贝棋盘
#             board_copy.move(action)                  # 新棋盘上行动
#             successors.append(Node(board=board_copy, depth=self.depth+1))
#         return successors
#
#     def get_ordered_successors(self, eval_func):
#         successors = self.get_successors()
#         values = list(map(lambda x: x.get_value(eval_func), successors))
#         # max_num_successors = self._board.width // 2 - self.depth
#         return sorted(successors,
#                       key=lambda x: values[successors.index(x)],
#                       reverse=self.rule == "max")[:15]
#
#     def get_ordered_successors(self, eval_func):
#         successors = []
#         for action in self.get_ordered_actions(eval_func):
#             board_copy = copy.deepcopy(self._board)  # 深拷贝棋盘
#             board_copy.move(action)  # 新棋盘上行动
#             successors.append(Node(board=board_copy, action=action, depth=self.depth+1))
#         return successors


# class MinimaxSearch:
#     def __init__(self, board, eval_func):
#         self.root = Node(board)
#         self.eval_func = eval_func
#
#     def get_value(self, node, alpha, beta, depth):
#         if node.is_leaf:  # 是叶结点，代表对局胜负已分
#             if node.state == "DRAW":
#                 return 0, None    # 没有胜利者，代表棋盘已满，和局，返回分数0，无动作
#             return float("inf") if node.state == "BLACK" else float("-inf"), None   # 返回胜利者对应的分数（正负无穷），无动作
#         if depth > MAX_DEPTH:
#             return node.get_value(self.eval_func), None  # 超出最大深度，返回评估分数，无动作
#         elif node.rule == "max":
#             return self.max_value(node, alpha, beta, depth)  # 非叶子节点，且是我方行动
#         else:
#             return self.min_value(node, alpha, beta, depth)  # 非叶子节点，且是对方行动
#
#     def max_value(self, node, alpha, beta, depth):
#         action = None
#         value = float("-inf")  # max结点的初始v值
#         for cur_action in node.get_ordered_actions(self.eval_func):
#             successor = node.get_successor(cur_action)
#             cur_value, _ = self.get_value(successor, alpha, beta, depth+1)
#             node.revert()
#             if cur_value == float("inf"):  # 子节点我方已获胜，直接返回
#                 return cur_value, cur_action
#             elif cur_value > value or cur_value == value == float("-inf"):
#                 value = cur_value
#                 action = cur_action  # 目前为止最好的value和action
#             if value >= beta:
#                 return value, cur_action  # 剪枝，且不关心这个结点的当前步动作
#             alpha = max(alpha, value)
#         return value, action
#
#     def min_value(self, node, alpha, beta, depth):
#         action = None
#         value = float("inf")  # min结点的初始v值
#         for cur_action in node.get_ordered_actions(self.eval_func):
#             successor = node.get_successor(cur_action)
#             cur_value, _ = self.get_value(successor, alpha, beta, depth+1)
#             node.revert()
#             if cur_value == float("-inf"):  # 子节点对方已获胜，直接返回
#                 return cur_value, cur_action
#             elif cur_value < value or cur_value == value == float("inf"):
#                 value = cur_value
#                 action = cur_action  # 目前为止最好的value和action
#             if value <= alpha:
#                 return value, cur_action  # 剪枝，且不关心这个结点的当前步动作
#             beta = min(beta, value)
#         return value, action
#
#     def solve(self):
#         _, first_action = self.get_value(self.root, float("-inf"), float("inf"), 0)
#         return first_action


class NegaMaxSearch:
    def __init__(self, board, ):
        self.root = Node(board)
        self.eval_func = Evaluator()
        self.best_action = None

    def get_value(self, node, alpha, beta, depth):
        if depth > MAX_DEPTH or node.is_leaf:
            return node.value  # 到达最大深度或胜负已分，返回估值（在get_ordered_actions()时已计算，并保存在value属性中）
        if MAX_DEPTH == 5:
            max_actions = 15 - 3 * depth
        elif MAX_DEPTH == 4:
            max_actions = 14 - 3 * depth
        elif MAX_DEPTH == 3:
            max_actions = 20 - 5 * depth
        elif MAX_DEPTH == 2:
            max_actions = 50
        else:
            max_actions = 100

        action_score_pairs = node.get_ordered_actions(self.eval_func)[:max_actions]
        if len(action_score_pairs) == 1 and depth == 0:
            action, board_score = action_score_pairs[0]
            self.best_action = action
            return board_score if node.rule == "max" else -board_score
        for cur_action, board_score in action_score_pairs:
            self.eval_func = Evaluator()
            successor = node.get_successor(cur_action, board_score=board_score)
            cur_value = -self.get_value(successor, -beta, -alpha, depth + 1)
            node.revert()
            if cur_value > alpha:  # NegaMax Search中，alpha值即为best_value值
                alpha = cur_value
                if depth == 0:
                    self.best_action = cur_action
            if cur_value >= beta:
                return cur_value
        return alpha

    def solve(self):
        self.get_value(self.root, float("-inf"), float("inf"), 0)
        return self.best_action


class RandomSearch:
    def __init__(self, board):
        self.root = Node(board)

    def solve(self):
        first_action = random.choice(list(self.root.get_actions()))
        return first_action


def main():
    b = Board(BOARD_SIZE)
    # op_move = [(1, 10), (2, 10), (1, 12), (1, 13)]
    # my_move = [(2, 11), (3, 11), (4, 11), (5, 11)]
    # for i in range(len(op_move)):
    #     op = op_move[i]
    #     b.move((op[0]-1, op[1]-1))
    #     my = my_move[i]
    #     b.move((my[0]-1, my[1]-1))
    # white_ai = NegaMaxSearch(board=b)
    # cur_action = white_ai.solve()
    # print(b)
    # b.move((0, 10))
    # print(b)
    #
    # white_ai = NegaMaxSearch(board=b)
    # cur_action = white_ai.solve()
    # b.move(cur_action)
    # print(b)

    # b.move((3, 1))
    # print(b)
    #
    # white_ai = NegaMaxSearch(board=b, eval_func=ef)
    # cur_action = white_ai.solve()
    # b.move(cur_action)
    # print(b)

    # b.move((5, 5))
    # b.move((9, 7))
    # b.move((5, 6))
    # b.move((9, 8))
    # b.move((9, 5))
    # b.move((9, 6))
    # print(b)
    #
    # print(b.hall)
    # ef.get_position_score(b, (9, 9))
    # print(ef.get_position_score(b, (5, 5)))
    # print(ef.get_position_score(b, (9, 6)))
    # print(ef.get_board_score(b))
    global MAX_DEPTH
    while True:
        MAX_DEPTH = 2
        black_ai = NegaMaxSearch(board=b)
        cur_action = black_ai.solve()
        b.move(cur_action)
        b.check_if_terminated()
        print(b)
        if b.state:
            break
        MAX_DEPTH = 4
        white_ai = NegaMaxSearch(board=b)
        cur_action = white_ai.solve()
        b.move(cur_action)
        b.check_if_terminated()
        print(b)
        if b.state:
            break
    print(b.state)
    # b.read_board("new.txt")
    # b.turn = WHITE
    # b.last_action = (3, 2)
    # print(b)
    #
    # white_ai = MinimaxSearch(board=b)
    # cur_action = white_ai.solve()
    # b.move(cur_action)
    # print(b)


if __name__ == "__main__":
    pass
    # main()
