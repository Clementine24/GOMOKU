BOARD_SIZE = 20
BLACK = 0          # 表示玩家轮次，而非棋子类型
WHITE = 1
EMPTY_CHESS = '.'
BLACK_CHESS = 'o'  # 表示棋子类型
WHITE_CHESS = 'x'
BLACK_CHESS_CUR = 'O'
WHITE_CHESS_CUR = 'X'
MAX_DEPTH = 5      # MinimaxSearch最大搜索深度
NEIGHBOR_RADIUS = 1

