import pisqpipe as pp
from pisqpipe import DEBUG_EVAL, DEBUG
import UCT
from Board import Board
from Evaluator import Evaluator
import random
import copy

pp.infotext = 'name="pbrain-pyrandom", author="Jan Stransky", version="1.0", country="Czech Republic", ' \
			  'www="https://github.com/stranskyjan/pbrain-pyrandom" '

MAX_BOARD = 20
board = Board(MAX_BOARD, MAX_BOARD)
ef = Evaluator()


def brain_init():
	global board
	if pp.width is None:
		pp.width = 20
	if pp.height is None:
		pp.height = 20
	if pp.width < 5 or pp.height < 5:
		pp.pipeOut("ERROR size of the board")
		return
	if pp.width > MAX_BOARD or pp.height > MAX_BOARD:
		pp.pipeOut("ERROR Maximal board size is {}".format(MAX_BOARD))
		return
	board = Board(pp.height, pp.width)
	pp.pipeOut("OK")


def brain_restart():
	global board, ef
	board = Board(pp.height, pp.width)
	ef = Evaluator()
	pp.pipeOut("OK")


def isFree(x, y):
	return board.is_empty((x, y))


def brain_my(x, y):
	if isFree(x, y):
		board.move((x, y))
	else:
		pp.pipeOut("ERROR my move [{},{}]".format(x, y))


def brain_opponents(x, y):
	if isFree(x, y):
		board.move((x, y))
	else:
		pp.pipeOut("ERROR opponents's move [{},{}]".format(x, y))


def brain_block(x, y):
	raise NotImplementedError
	# if isFree(x, y):
	# 	board[x][y] = 3
	# else:
	# 	pp.pipeOut("ERROR winning move [{},{}]".format(x, y))


def brain_takeback(x, y):
	raise NotImplementedError
	# if 0 <= x < pp.width and 0 <= y < pp.height and board[x][y] != 0:
	# 	board[x][y] = 0
	# 	return 0
	# return 2


def brain_turn():
	if pp.terminateAI:
		return
	random.seed(1234)
	evaluator = Evaluator()
	x, y = UCT.UCTSearchAgent(copy.deepcopy(board), evaluator).solve()
	pp.do_mymove(x, y)

# def brain_turn():
#     if pp.terminateAI:
#         return
#     i = 0
#     while True:
#         x = random.randint(0, pp.width)
#         y = random.randint(0, pp.height)
#         i += 1
#         if pp.terminateAI:
#             return
#         if isFree(x, y):
#             break
#     if i > 1:
#         pp.pipeOut("DEBUG {} coordinates didn't hit an empty field".format(i))
#     pp.do_mymove(x, y)

def brain_end():
	pass


def brain_about():
	pp.pipeOut(pp.infotext)


if DEBUG_EVAL:
	import win32gui


	def brain_eval(x, y):
		# TODO check if it works as expected
		wnd = win32gui.GetForegroundWindow()
		dc = win32gui.GetDC(wnd)
		rc = win32gui.GetClientRect(wnd)
		c = str(board[x][y])
		win32gui.ExtTextOut(dc, rc[2] - 15, 3, 0, None, c, ())
		win32gui.ReleaseDC(wnd, dc)

######################################################################
# A possible way how to debug brains.
# To test it, just "uncomment" it (delete enclosing """)
######################################################################

# # define a file for logging ...
# DEBUG_LOGFILE = "D:/课程/5/人工智能/pjs/final/main-files/pbrain-minimax.log"
# # ...and clear it initially
#
# with open(DEBUG_LOGFILE, "w") as f:
#     pass
#
# # define a function for writing messages to the file
#
# def logDebug(msg):
# 	with open(DEBUG_LOGFILE, "a") as f:
# 		f.write(msg+"\n")
# 		f.flush()
#
# # define a function to get exception traceback
# def logTraceBack():
# 	import traceback
# 	with open(DEBUG_LOGFILE, "a") as f:
# 		traceback.print_exc(file=f)
# 		f.flush()
# 	raise

# use logDebug wherever
# use try-except (with logTraceBack in except branch) to get exception info
# an example of problematic function
# def brain_turn():
# 	logDebug("some message 1")
# 	try:
# 		logDebug("some message 2")
# 		1. / 0. # some code raising an exception
# 		logDebug("some message 3") # not logged, as it is after error
# 	except:
# 		logTraceBack()

######################################################################

# "overwrites" functions in pisqpipe module
pp.brain_init = brain_init
pp.brain_restart = brain_restart
pp.brain_my = brain_my
pp.brain_opponents = brain_opponents
pp.brain_block = brain_block
pp.brain_takeback = brain_takeback
pp.brain_turn = brain_turn
pp.brain_end = brain_end
pp.brain_about = brain_about
if DEBUG_EVAL:
	pp.brain_eval = brain_eval


def main():
	pp.main()


if __name__ == "__main__":
	main()
