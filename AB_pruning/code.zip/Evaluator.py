from config import *
from Board import Board


class Evaluator:
    BLACK_CHESS = BLACK_CHESS
    WHITE_CHESS = WHITE_CHESS
    EMPTY_CHESS = EMPTY_CHESS
    directions = ((0, 1), (1, 0), (1, 1), (1, -1))
    score_table = {  # 8种棋型的分数表
        'zero': 0,
        's2': 10,
        'l2': 100,
        's3': 100,
        'l3': 1000,
        's4': 5000,
        'l4': 10000,
        'five': 1000000
    }
    size = BOARD_SIZE

    def __init__(self):
        self.scoredtable = [[[0, 0, 0, 0] for i in range(self.size)] for y in range(self.size)]  # 记录已经评过分的节点

    def restart(self):  # 每次计算棋盘得分时需要清零之前的记录数据
        self.scoredtable = [[[0, 0, 0, 0] for i in range(self.size)] for y in range(self.size)]  # 记录已经评过分的节点
        self.diffscores = [[0 for x in range(8)] for y in range(2)]  # 记录黑子白子不同棋型出现个数

    def get_board_score(self, board: Board) -> dict[int: int, int: int]:
        self.restart()
        black_positions = board.get_black_chess()
        white_positions = board.get_white_chess()
        black_scores = 0
        white_scores = 0
        for b_pos in black_positions:
            # black_scores += self.get_position_player_score(board, b_pos)
            black_scores += self.get_position_score(board, b_pos)[BLACK]
        for w_pos in white_positions:
            # white_scores += self.get_position_player_score(board, w_pos)
            white_scores += self.get_position_score(board, w_pos)[WHITE]
        return {BLACK: black_scores, WHITE: white_scores}

    def get_all_positions_scores(self, board: Board, positions) -> dict[tuple[int, int]: int]:
        score_dict = {}
        for position in positions:
            score_dict[position] = self.get_position_score(board, position)
        return score_dict

    def get_position_score(self, board, position) -> dict[int: int, int: int]:
        owner = board.whose_chess(position)
        scores = {BLACK: 0, WHITE: 0}
        if owner is None:
            for player in [BLACK, WHITE]:
                board.move(position, player=player)
                scores[player] = self.get_position_player_score(board, position, simulation=True)
                board.withdraw(position)
        elif owner == BLACK:
            scores[BLACK] = self.get_position_player_score(board, position)
        else:
            scores[WHITE] = self.get_position_player_score(board, position)
        return scores

    def get_position_player_score(self, board, position, simulation=False) -> int:
        total_score = 0
        for i in range(4):
            if self.scoredtable[position[0]][position[1]][i] == 1 and not simulation:
                direction_score = 0  # 检测如果该点在这个方向上已经作为其他棋型记过分了，则不再重复计分
            else:
                direction = Evaluator.directions[i]
                direction_score = self.get_position_direction_player_score(board, position, direction, simulation)
                # print(direction_score)
            total_score += direction_score

        return total_score

    def get_position_direction_player_score(self, board, position, direction, simulation) -> int:
        if board.whose_chess(position) == BLACK:
            my = BLACK
            oppo = WHITE
        else:
            my = WHITE
            oppo = BLACK

        chessshape = self.get_nine_chess(board, position, direction, my,oppo)
        chesstype = self.get_chess_type(board, chessshape, my, oppo, direction, position, simulation)
        return chesstype

    def get_nine_chess(self, board, position, direction, my, oppo):
        chesstype = []
        for i in range(-4, 5):
            if (position[0] + i * direction[0] < 0) \
                    or (position[1] + i * direction[1] < 0) \
                    or (position[0] + i * direction[0] >= self.size) \
                    or (position[1] + i * direction[1] >= self.size):  # 当读取棋子范围超过边界时，将其记为对方棋子
                chesstype.append(2)
            elif board.whose_chess([position[0] + i * direction[0], position[1] + i * direction[1]]) == my:
                chesstype.append(1)
            elif board.whose_chess([position[0] + i * direction[0], position[1] + i * direction[1]]) == oppo:
                chesstype.append(2)
            else:
                chesstype.append(0)
        return chesstype

    def record_scored_chess(self, position, chess_left_bound, chess_right_bound, direction, simulation):
        if simulation:
            return
        k = self.directions.index(direction)
        for i in range(chess_left_bound, chess_right_bound + 1):
            self.scoredtable[position[0] - (4 - i) * direction[0]][position[1] - (4 - i) * direction[1]][k] = 1

    def get_chess_type(self, board, chessshape, my, oppo, direction, position, simulation):
        chess_left_bound = 4  # 我方完整棋型的右边界
        chess_right_bound = 4  # 我方完整棋型的左边界
        mychess_left_bound = 4  # 我方连续的右边界
        mychess_right_bound = 4  # 我方连续的左边界
        go = True
        for i in range(1, 5):
            if chessshape[chess_right_bound + 1] == 2:
                break
            chess_right_bound += 1
            if go and chessshape[mychess_right_bound + 1] == 1:
                mychess_right_bound += 1
            else:
                go = False
        go = True
        for i in range(1, 5):
            if chessshape[chess_left_bound - 1] == 2:
                break
            chess_left_bound -= 1
            if go and chessshape[mychess_left_bound - 1] == 1:
                mychess_left_bound -= 1
            else:
                go = False
        chesslen = chess_right_bound - chess_left_bound + 1
        if chesslen < 5:  # 无棋型
            self.record_scored_chess(position, chess_left_bound, chess_right_bound, direction, simulation)
            return self.score_table['zero']
        mychesslen = mychess_right_bound - mychess_left_bound + 1
        if mychesslen >= 5:  # 连五
            self.record_scored_chess(position, mychess_left_bound, mychess_right_bound, direction, simulation)
            return self.score_table['five']
        self.record_scored_chess(position, mychess_left_bound, mychess_right_bound, direction, simulation)
        if mychesslen == 4:
            # 011110活四
            if chessshape[mychess_left_bound - 1] == 0 and chessshape[mychess_right_bound + 1] == 0:
                return self.score_table['l4']
            # 011112/211110冲四
            elif chessshape[mychess_left_bound - 1] == 0 or chessshape[mychess_right_bound + 1] == 0:
                return self.score_table['s4']
        if mychesslen == 3:
            # 10111、11101冲四
            if chessshape[mychess_left_bound - 2] == 1 and not chessshape[mychess_left_bound - 1]:
                self.record_scored_chess(position, mychess_left_bound - 2, mychess_left_bound - 1, direction, simulation)
                return self.score_table['s4']
            elif chessshape[mychess_right_bound + 2] == 1 and not chessshape[mychess_right_bound + 1]:
                self.record_scored_chess(position, mychess_right_bound + 1, mychess_right_bound + 2, direction, simulation)
                return self.score_table['s4']
            elif not chessshape[mychess_left_bound - 1] and not chessshape[mychess_right_bound + 1]:
                # 活三011100/001110
                if chesslen > 5:
                    return self.score_table['l3']
                # 冲三2011102
                else:
                    return self.score_table['s3']
            # 只可能是冲三211100/001112
            else:
                return self.score_table['s3']
        if mychesslen == 2:
            if not chessshape[mychess_right_bound + 1]:
                # 先判断冲四11011
                if chessshape[mychess_right_bound + 2] == 1 and chessshape[mychess_right_bound + 3] == 1:
                    self.record_scored_chess(position, mychess_right_bound + 1, mychess_right_bound + 3, direction, simulation)
                    return self.score_table['s4']
                # 再判断活三011010
                elif chessshape[mychess_right_bound + 2] == 1:
                    if not chessshape[mychess_left_bound - 1] and not chessshape[mychess_right_bound + 3]:
                        self.record_scored_chess(position, mychess_right_bound + 1, mychess_right_bound + 2, direction, simulation)
                        return self.score_table['l3']
                    # 再判断冲三211010/011012
                    elif chessshape[mychess_left_bound - 1] == 2 and not chessshape[mychess_right_bound + 3]:
                        self.record_scored_chess(position, mychess_right_bound + 1, mychess_right_bound + 2, direction, simulation)
                        return self.score_table['s3']
                    elif not chessshape[mychess_left_bound - 1] and chessshape[mychess_right_bound + 3] == 2:
                        self.record_scored_chess(position, mychess_right_bound + 1, mychess_right_bound + 2, direction, simulation)
                        return self.score_table['s3']
            # 判断以上三种情况的对称情况
            if not chessshape[mychess_left_bound - 1]:
                # 先判断冲四11011
                if chessshape[mychess_left_bound - 2] == 1 and chessshape[mychess_left_bound - 3] == 1:
                    self.record_scored_chess(position, mychess_left_bound - 3, mychess_left_bound - 1, direction, simulation)
                    return self.score_table['s4']
                # 再判断活三010110
                elif chessshape[mychess_left_bound - 2] == 1:
                    if not chessshape[mychess_right_bound + 1] and not chessshape[mychess_left_bound - 3]:
                        self.record_scored_chess(position, mychess_left_bound - 2, mychess_left_bound - 1, direction, simulation)
                        return self.score_table['l3']
                    # 再判断冲三210110/010112
                    elif chessshape[mychess_right_bound + 1] == 2 and not chessshape[mychess_left_bound - 3]:
                        self.record_scored_chess(position, mychess_left_bound - 2, mychess_left_bound - 1, direction, simulation)
                        return self.score_table['s3']
                    elif not chessshape[mychess_right_bound + 1] and chessshape[mychess_left_bound - 3] == 2:
                        self.record_scored_chess(position, mychess_left_bound - 2, mychess_left_bound - 1, direction, simulation)
                        return self.score_table['s3']
            # 活二001100/011000/000110
            if chesslen > 5 and not chessshape[mychess_right_bound + 1] and not chessshape[mychess_left_bound - 1]:
                return self.score_table['l2']
            # 冲二211、112
            if not chessshape[mychess_right_bound + 1] or not chessshape[mychess_left_bound - 1]:
                return self.score_table['s2']
        if mychesslen == 1:
            # 活二01010/010010
            if not chessshape[mychess_left_bound - 1] and not chessshape[mychess_right_bound + 1]:
                if chessshape[mychess_right_bound + 2] == 1 and not chessshape[mychess_right_bound + 3]:
                    return self.score_table['l2']
                elif chessshape[mychess_right_bound + 3] == 1 and \
                        not chessshape[mychess_right_bound + 1] and not chessshape[mychess_right_bound + 2]:
                    return self.score_table['l2']
            # 冲二21010
            if not chessshape[mychess_right_bound + 1] and not chessshape[mychess_right_bound + 3] \
                    and chessshape[mychess_right_bound + 2] == 1:
                return self.score_table['s2']
            # 冲二01012
            if not chessshape[mychess_left_bound - 1] and not chessshape[mychess_right_bound + 1] \
                    and chessshape[mychess_right_bound + 2] == 1:
                return self.score_table['s2']
        return 0
