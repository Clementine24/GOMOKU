from config import *


class Board:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self._grid = [[EMPTY_CHESS for _ in range(self.width)] for _ in range(self.height)]
        self.turn = BLACK
        self.pre_actions = []  # 之前下过的棋的位置序列
        self.empty_positions = {(x, y) for x in range(self.height) for y in range(self.width)}  # 记录未落子点
        self.black_positions = set()  # 记录黑棋已落子点
        self.white_positions = set()  # 记录白棋已落子点
        self.hall = set()  # 记录“包”：周围有至少一个已落子点的未落子点
        self.state = None

    def __getitem__(self, index):
        """
        添加Board[][] 索引语法
        :param index: 下标索引
        :return:
        """
        return self._grid[index]

    def __setitem__(self, index, value):
        """
        设置Board[][] 索引语法
        :param index: 下标索引
        :return:
        """
        self._grid[index] = value

    def __repr__(self):
        """
        转化为字符串
        :param:
        :return:
        """

        if self.pre_actions:
            last_action = self.pre_actions[-1]
            last_x, last_y = last_action
            self._grid[last_x][last_y] = BLACK_CHESS_CUR if self.turn == WHITE else WHITE_CHESS_CUR

        res = f"Here is the board of {self.height}*{self.width}.\n"
        res += "   "
        for x in range(self.height):
            res += f"{x:2}|"
        res += "\n"
        for x in range(self.height):
            res += f"{x:2}: "
            for y in range(self.width):
                res += self._grid[x][y] + "| "
            res += "\n"

        if self.pre_actions:
            last_action = self.pre_actions[-1]
            last_x, last_y = last_action
            self._grid[last_x][last_y] = BLACK_CHESS if self.turn == WHITE else WHITE_CHESS
        return res

    def is_on_board(self, position):
        x, y = position
        return 0 <= x < self.height and 0 <= y < self.width

    def is_empty(self, position):
        x, y = position
        return self.is_on_board(position) and self._grid[x][y] == EMPTY_CHESS

    def whose_chess(self, position):
        assert self.is_on_board(position)
        x, y = position
        if self._grid[x][y] == BLACK_CHESS:
            return BLACK
        elif self._grid[x][y] == WHITE_CHESS:
            return WHITE
        else:
            return None

    def get_black_chess(self):
        return self.black_positions

    def get_white_chess(self):
        return self.white_positions

    def move(self, position, player=None, update=True):
        assert position is not None
        assert self.is_empty(position)
        x, y = position
        if player is None:
            if self.turn == BLACK:
                self._grid[x][y] = BLACK_CHESS
                self.black_positions.add(position)
                self.turn = WHITE
            else:
                self._grid[x][y] = WHITE_CHESS
                self.white_positions.add(position)
                self.turn = BLACK
            if update:
                self.pre_actions.append(position)
                self.empty_positions.discard(position)
                self.update_hall()
        else:
            self._grid[x][y] = BLACK_CHESS if player == BLACK else WHITE_CHESS

    def check_if_terminated(self):
        if not self.pre_actions:  # 如果未落子（空棋盘），不可能是终止状态
            self.state = None
            return False
        last_action = self.pre_actions[-1]
        if not self.empty_positions:
            self.state = "DRAW"
            return True
        last_x, last_y = last_action
        for direction in [(0, 1), (1, 0), (1, 1), (1, -1)]:
            dire_x, dire_y = direction
            pre_chess = None
            cum_length = 0
            for i in range(-4, 5):
                cur_x, cur_y = last_x + i * dire_x, last_y + i * dire_y
                cur = (cur_x, cur_y)
                if not self.is_on_board(cur):
                    continue
                cur_chess = self.whose_chess(cur)
                if pre_chess != cur_chess:
                    pre_chess = cur_chess
                    cum_length = 1
                else:
                    cum_length += 1
                    if cum_length == 5:
                        self.state = "BLACK" if cur_chess == BLACK else "WHITE"
                        return True
        self.state = None
        return False

    def update_hall(self):  # 更新棋盘的“包”
        last_action = self.pre_actions[-1]
        for position in self.get_empty_neighbors(last_action):
            self.hall.add(position)
        self.hall.discard(last_action)  # 删除上一步已下的点

    def revert_hall(self):
        last_action = self.pre_actions[-1]
        for position in self.get_empty_neighbors(last_action):
            if not self.has_nonempty_neighbors(position):
                self.hall.discard(position)  # 周围没有已落子点，删去
        if self.has_nonempty_neighbors(last_action):
            self.hall.add(last_action)

    def withdraw(self, position=None):
        if position is None:
            assert self.pre_actions
            last_action = self.pre_actions[-1]
            last_turn = WHITE if self.turn == BLACK else BLACK
            assert self.whose_chess(last_action) == last_turn
            last_x, last_y = last_action
            self._grid[last_x][last_y] = EMPTY_CHESS
            self.turn = last_turn
            if last_turn == BLACK:
                self.black_positions.discard(last_action)
            else:
                self.white_positions.discard(last_action)
            self.empty_positions.add(last_action)
            self.revert_hall()
            self.pre_actions.pop()
        else:
            x, y = position
            self._grid[x][y] = EMPTY_CHESS

    def has_nonempty_neighbors(self, position, radius=NEIGHBOR_RADIUS):
        x, y = position
        for i in range(-radius, radius + 1):
            for j in range(-radius, radius + 1):
                if self.is_on_board((x+i, y+j)) and (i != 0 or j != 0) and self._grid[x+i][y+j] != EMPTY_CHESS:
                    return True
        return False

    def get_empty_neighbors(self, position, radius=NEIGHBOR_RADIUS):
        """Returns the empty neighbors"""
        x, y = position
        neighbors = set()
        for i in range(-radius, radius + 1):
            for j in range(-radius, radius + 1):
                if self.is_empty((x+i, y+j)) and (i != 0 or j != 0):
                    neighbors.add((x+i, y+j))
        return neighbors


def main():
    board = Board(10, 10)
    board.move((0, 0))
    board.move((1, 0))

    board.move((0, 1))
    board.move((1, 1))
    board.move((3, 2))
    board.move((1, 2))
    board.move((0, 3))
    board.move((1, 3))
    board.move((0, 4))
    board.move((1, 5))

    print(board)
    print(board.check_if_terminated())
    print(board.hall)
    print(len(board.hall))

    board.withdraw()
    print(board)
    print(board.check_if_terminated())
    print(board.state)
    print(board.hall)


if __name__ == "__main__":
    main()
